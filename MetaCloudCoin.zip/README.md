# MetaCloudCoin (MCC)

MetaCloudCoin is a decentralized digital currency based on public cloud metadata.
